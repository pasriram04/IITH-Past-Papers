#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
	// Generates Random number between 0 and 1
	double r;
	srand(time(NULL));
	r = (double) rand()/(double)RAND_MAX;
	printf("%lf \n", r);

	// Read File Contents 
	FILE *file;
	double col1[MAX_ROWS];
    	double col2[MAX_ROWS];
    	int i = 0;

    	file = fopen("PW_MeanResistance.dat", "r");

    	if (file == NULL) {
        	printf("Error: Could not open file.\n");
        	return 1;
    	}	

    	// Read two doubles per line
    	while (i < MAX_ROWS) {
		fscanf(file, "%lf %lf", &col1[i], &col2[i]); 
        	i++;
    	}

	fclose(file);
	return(0);
}
