#include <stdio.h>
#include <stdlib.h>

#define MAX_ROWS 11

int main() {
    FILE *file;
    double col1[MAX_ROWS];
    double col2[MAX_ROWS];
    int i = 0;

    file = fopen("PW_MeanResistance.dat", "r");

    if (file == NULL) {
        printf("Error: Could not open file.\n");
        return 1;
    }

    // Read two integers per line
    while (i < MAX_ROWS) {
	fscanf(file, "%lf %lf", &col1[i], &col2[i]); 
        i++;
    }

    fclose(file);

    // Print the data
    printf("Column 1\tColumn 2\n");
    for (int j = 0; j < i; j++) {
        printf("%lf\t\t%lf\n", col1[j], col2[j]);
    }

    return 0;
}

